<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Jonah - analyse engine</title>
	<link href="/jonahv1/css/main.css" type="text/css" rel="stylesheet">
    <script src="/jonahv1/scripts/libraries.js" type="text/javascript"></script>
    <META HTTP-EQUIV="MSThemeCompatible" Content="Yes">

</head>

<body>
<table cellpadding="0" cellspacing="0" class="jonahtable">
<tr valign="top">	
<td>

</td>
<td>

<!-- // mockup for ftp queue -->
<?php include ('/var/www/html/jonahv1/inc/analyse-view.php'); ?>

<br /><br />

<!-- // -->
</td><!-- end of content cell in main table // -->
</tr>

<tr><td align="left" valign="bottom"><form valign="bottom"><INPUT class="softbutton" onClick="showDebug()" value="showDebug()" type="button" disabled="disabled"></form></td><td align="center">
<?php include ('/var/www/html/jonahv1/inc/adminfooter.php'); ?>
</td></tr>
</table>

</body>
</html>	